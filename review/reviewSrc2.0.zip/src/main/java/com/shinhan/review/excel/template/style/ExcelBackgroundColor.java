package com.shinhan.review.excel.template.style;

import org.apache.poi.ss.usermodel.CellStyle;

public interface ExcelBackgroundColor{
    void applyBackground(CellStyle cellStyle);
}
