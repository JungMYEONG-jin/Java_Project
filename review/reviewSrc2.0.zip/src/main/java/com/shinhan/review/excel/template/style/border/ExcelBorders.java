package com.shinhan.review.excel.template.style.border;

import org.apache.poi.ss.usermodel.CellStyle;

public interface ExcelBorders {
    void apply(CellStyle cellStyle);
}
