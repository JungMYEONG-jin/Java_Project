package com.shinhan.review.excel.ver2.style.border;

import org.apache.poi.ss.usermodel.CellStyle;

public interface ExcelBorders {

	void apply(CellStyle cellStyle);

}
