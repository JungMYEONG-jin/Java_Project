package com.shinhan.review.excel.ver2;

public class ExcelException extends RuntimeException {

	public ExcelException(String message, Throwable cause) {
		super(message, cause);
	}

}
