package com.shinhan.review.excel.template.style.color;

import org.apache.poi.ss.usermodel.CellStyle;

public interface ExcelColor {
    void applyForeGround(CellStyle cellStyle);
}
