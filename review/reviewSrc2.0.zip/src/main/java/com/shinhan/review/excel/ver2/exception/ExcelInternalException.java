package com.shinhan.review.excel.ver2.exception;

import com.shinhan.review.excel.ver2.ExcelException;

public class ExcelInternalException extends ExcelException {

	public ExcelInternalException(String message, Throwable cause) {
		super(message, cause);
	}

}
