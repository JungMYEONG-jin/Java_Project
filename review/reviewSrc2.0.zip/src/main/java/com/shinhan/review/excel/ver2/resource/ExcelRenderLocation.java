package com.shinhan.review.excel.ver2.resource;

public enum ExcelRenderLocation {

	HEADER, BODY

}
