package com.shinhan.review.excel.ver2.style.align;

import org.apache.poi.ss.usermodel.CellStyle;

public interface ExcelAlign {

	void apply(CellStyle cellStyle);

}
