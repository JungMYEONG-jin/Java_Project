package com.shinhan.review.excel.template.style.align;

import org.apache.poi.ss.usermodel.CellStyle;

public interface ExcelAlign {
    void apply(CellStyle cellStyle);
}
