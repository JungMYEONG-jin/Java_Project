package com.shinhan.review.excel.template.style.color;

import org.apache.poi.ss.usermodel.CellStyle;

public class NoExcelColor implements ExcelColor {
    @Override
    public void applyForeGround(CellStyle cellStyle) {

    }
}
