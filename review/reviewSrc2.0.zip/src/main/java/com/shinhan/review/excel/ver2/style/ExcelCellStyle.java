package com.shinhan.review.excel.ver2.style;

import org.apache.poi.ss.usermodel.CellStyle;

public interface ExcelCellStyle {

	void apply(CellStyle cellStyle);

}
