package com.shinhan.review.excel.ver2.style.color;

import org.apache.poi.ss.usermodel.CellStyle;

public interface ExcelColor {

	void applyForeground(CellStyle cellStyle);

}
